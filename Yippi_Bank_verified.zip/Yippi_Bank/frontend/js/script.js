document.addEventListener("DOMContentLoaded", () => {
    const API_URL = `${window.location.origin}/api`;
    let currentToken = sessionStorage.getItem("yippiToken");

    const $ = (id) => document.getElementById(id);

    function showMessage(message, color = "red") {
        const box = $("message");
        if (!box) return;
        box.textContent = message;
        box.style.color = color;
    }

    async function apiRequest(path, options = {}) {
        const headers = { ...(options.headers || {}) };

        if (options.body) headers["Content-Type"] = "application/json";
        if (currentToken) headers.Authorization = `Bearer ${currentToken}`;

        const response = await fetch(`${API_URL}${path}`, {
            ...options,
            headers
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.message || `Request failed (${response.status}).`);
        }

        return data;
    }

    $("registerForm").addEventListener("submit", async function (event) {
        event.preventDefault();

        try {
            const data = await apiRequest("/auth/register", {
                method: "POST",
                body: JSON.stringify({
                    full_name: $("full_name").value.trim(),
                    email: $("register_email").value.trim(),
                    password: $("register_password").value
                })
            });

            showMessage(data.message || "Registration successful. Please log in.", "green");
            this.reset();
        } catch (error) {
            showMessage(error.message);
        }
    });

    $("loginForm").addEventListener("submit", async function (event) {
        event.preventDefault();

        try {
            const data = await apiRequest("/auth/login", {
                method: "POST",
                body: JSON.stringify({
                    email: $("login_email").value.trim(),
                    password: $("login_password").value
                })
            });

            currentToken = data.token;
            sessionStorage.setItem("yippiToken", currentToken);

            $("customerName").textContent = `Welcome, ${data.user.full_name}`;
            $("registerForm").style.display = "none";
            $("loginForm").style.display = "none";
            $("dashboard").style.display = "block";

            showMessage("Login successful.", "green");
            this.reset();

            await loadDashboard();
        } catch (error) {
            showMessage(error.message);
        }
    });

    async function loadDashboard() {
        const data = await apiRequest("/dashboard");

        $("balance").textContent =
            "₦" + Number(data.balance).toLocaleString("en-NG", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });

        $("accountNumber").textContent = data.accountNumber;

        const list = $("transactionList");
        list.replaceChildren();

        if (!data.transactions.length) {
            const item = document.createElement("li");
            item.textContent = "No transactions yet.";
            list.appendChild(item);
            return;
        }

        data.transactions.forEach((transaction) => {
            const item = document.createElement("li");
            const date = new Date(transaction.created_at).toLocaleString();

            item.textContent =
                `${transaction.transaction_type.toUpperCase()} — ₦${Number(transaction.amount).toLocaleString("en-NG", {
                    minimumFractionDigits: 2
                })} — ${transaction.description || ""} — ${date}`;

            list.appendChild(item);
        });
    }

    async function makeTransaction(type) {
        const entered = prompt(`Enter ${type} amount in Naira (test funds only):`);

        if (entered === null) return;

        const amount = entered.trim();

        if (!/^(?:0|[1-9]\d{0,8})(?:\.\d{1,2})?$/.test(amount) || Number(amount) <= 0) {
            alert("Enter a valid positive amount with up to 2 decimal places.");
            return;
        }

        try {
            const data = await apiRequest(`/dashboard/${type}`, {
                method: "POST",
                body: JSON.stringify({ amount })
            });

            alert(data.message);
            await loadDashboard();
        } catch (error) {
            alert(error.message);
        }
    }

    $("depositBtn").addEventListener("click", () => makeTransaction("deposit"));
    $("withdrawBtn").addEventListener("click", () => makeTransaction("withdrawal"));

    $("logoutBtn").addEventListener("click", () => {
        currentToken = null;
        sessionStorage.removeItem("yippiToken");

        $("dashboard").style.display = "none";
        $("registerForm").style.display = "block";
        $("loginForm").style.display = "block";
        $("balance").textContent = "₦0.00";
        $("accountNumber").textContent = "Loading...";
        $("transactionList").innerHTML = "<li>No transactions yet.</li>";

        showMessage("You have logged out.", "green");
    });

    if (currentToken) {
        $("registerForm").style.display = "none";
        $("loginForm").style.display = "none";
        $("dashboard").style.display = "block";

        loadDashboard().catch((error) => {
            currentToken = null;
            sessionStorage.removeItem("yippiToken");

            $("dashboard").style.display = "none";
            $("registerForm").style.display = "block";
            $("loginForm").style.display = "block";

            showMessage(error.message);
        });
    }
});