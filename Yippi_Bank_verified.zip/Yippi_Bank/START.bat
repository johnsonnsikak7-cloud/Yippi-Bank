@echo off
cd /d "%~dp0backend"
start "" "http://127.0.0.1:3000"
npm start
