# Yippi Bank Demo

## Folder layout
- `backend/` — Express API, PostgreSQL connection, authentication, dashboard and transaction routes.
- `backend/sql/schema.sql` — database tables.
- `frontend/` — static website with original Yippi Bank demo branding and CSS illustration.

## Setup
1. In pgAdmin, open the `yippibank_db` database and run `backend/sql/schema.sql`.
2. In `backend/`, copy `.env.example` to `.env`.
3. Edit `.env` with your own local PostgreSQL username/password and a long random JWT_SECRET. Do not share `.env`.
4. Open PowerShell in the `backend` folder and run `npm install`.
5. Double-click `START.bat`, or run `npm start` in `backend/`.
6. Open `http://127.0.0.1:3000`. The same server hosts both the website and API.

## Important
This is an educational prototype, not a real bank or financial service. Deposits and withdrawals update simulated balances in the local database only. No real money, bank rails, payment processor, compliance, or production-grade ledger is involved. Do not use real banking credentials or use this application for financial activity.

The ZIP did not include image assets; the page uses an original, CSS-built Yippi Bank illustration instead.
