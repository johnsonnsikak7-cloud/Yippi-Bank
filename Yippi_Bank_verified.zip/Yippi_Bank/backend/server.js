require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    throw new Error("JWT_SECRET must be set to a random value of at least 32 characters.");
}

const app = express();
const PORT = Number(process.env.PORT || 3000);
const allowedOrigins = [
    "http://127.0.0.1:5500",
    "http://localhost:5500",
    `http://127.0.0.1:${PORT}`,
    `http://localhost:${PORT}`,
    ...(process.env.FRONTEND_ORIGIN || "").split(",").map((origin) => origin.trim()),
    process.env.RENDER_EXTERNAL_URL
].filter(Boolean);

app.use(helmet());
app.use(cors({
    origin(origin, callback) {
        if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
        return callback(new Error("Origin not allowed by CORS"));
    },
    credentials: true,
    methods: ["GET", "POST"],
    allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "..", "frontend")));

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 20,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    message: { success: false, message: "Too many attempts. Please try again later." }
});

app.use("/api/auth", authLimiter, require("./routes/auth"));
app.use("/api/dashboard", require("./routes/dashboard"));

app.get("/api/health", (req, res) => {
    res.json({ success: true, message: "Yippi Bank backend is connected." });
});

app.use((err, req, res, next) => {
    console.error("Request error:", err.message);
    if (res.headersSent) return next(err);
    if (err.message === "Origin not allowed by CORS") {
        return res.status(403).json({ success: false, message: "This website origin is not allowed." });
    }
    res.status(500).json({ success: false, message: "An unexpected server error occurred." });
});

app.listen(PORT, () => {
    console.log(`Yippi Bank backend is running on port ${PORT}`);
});
