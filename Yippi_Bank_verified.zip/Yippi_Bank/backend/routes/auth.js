const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const pool = require("../database");

const router = express.Router();

router.get("/test", (req, res) => {
    res.json({ success: true, message: "Yippi Bank authentication route is working." });
});

router.post("/register", async (req, res) => {
    try {
        const fullName = typeof req.body.full_name === "string" ? req.body.full_name.trim() : "";
        const email = typeof req.body.email === "string" ? req.body.email.trim().toLowerCase() : "";
        const password = typeof req.body.password === "string" ? req.body.password : "";

        if (!fullName || !email || !password) {
            return res.status(400).json({ success: false, message: "All fields are required." });
        }
        if (fullName.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
            return res.status(400).json({ success: false, message: "Enter a valid name and email address." });
        }
        if (password.length < 8 || password.length > 72) {
            return res.status(400).json({ success: false, message: "Password must be 8–72 characters." });
        }

        const passwordHash = await bcrypt.hash(password, 12);
        const result = await pool.query(
            `INSERT INTO users (full_name, email, password_hash)
             VALUES ($1, $2, $3)
             RETURNING id, full_name, email`,
            [fullName, email, passwordHash]
        );

        return res.status(201).json({
            success: true,
            message: "Customer registered successfully. Please log in.",
            user: result.rows[0]
        });
    } catch (error) {
        if (error.code === "23505") {
            return res.status(409).json({ success: false, message: "Email is already registered." });
        }
        console.error("Registration error:", error.message);
        return res.status(500).json({ success: false, message: "Registration failed. Please try again." });
    }
});

router.post("/login", async (req, res) => {
    try {
        const email = typeof req.body.email === "string" ? req.body.email.trim().toLowerCase() : "";
        const password = typeof req.body.password === "string" ? req.body.password : "";
        if (!email || !password) {
            return res.status(400).json({ success: false, message: "Email and password are required." });
        }

        const result = await pool.query(
            "SELECT id, full_name, email, password_hash FROM users WHERE email = $1",
            [email]
        );
        if (!result.rows.length) {
            return res.status(401).json({ success: false, message: "Invalid email or password." });
        }

        const user = result.rows[0];
        const matches = await bcrypt.compare(password, user.password_hash);
        if (!matches) {
            return res.status(401).json({ success: false, message: "Invalid email or password." });
        }

        const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
            algorithm: "HS256",
            expiresIn: "1h"
        });

        return res.json({
            success: true,
            message: "Login successful.",
            token,
            user: { id: user.id, full_name: user.full_name, email: user.email }
        });
    } catch (error) {
        console.error("Login error:", error.message);
        return res.status(500).json({ success: false, message: "Login failed. Please try again." });
    }
});

module.exports = router;
