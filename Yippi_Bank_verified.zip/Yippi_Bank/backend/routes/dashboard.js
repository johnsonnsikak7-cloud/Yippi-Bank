const express = require("express");
const pool = require("../database");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

async function ensureAccount(db, userId) {
    // This deterministic number is for this educational prototype only.
    const accountNumber = `YB${String(userId).padStart(10, "0")}`;
    await db.query(
        `INSERT INTO accounts (user_id, account_number)
         VALUES ($1, $2)
         ON CONFLICT (user_id) DO NOTHING`,
        [userId, accountNumber]
    );
    const result = await db.query(
        "SELECT id, account_number, balance FROM accounts WHERE user_id = $1",
        [userId]
    );
    if (!result.rows.length) throw new Error("Unable to create or retrieve account.");
    return result.rows[0];
}

router.get("/", authMiddleware, async (req, res) => {
    try {
        const userResult = await pool.query(
            "SELECT id, full_name, email FROM users WHERE id = $1",
            [req.user.userId]
        );
        if (!userResult.rows.length) {
            return res.status(404).json({ success: false, message: "Customer not found." });
        }

        const account = await ensureAccount(pool, req.user.userId);
        const transactions = await pool.query(
            `SELECT id, transaction_type, amount, description, created_at
             FROM transactions WHERE account_id = $1
             ORDER BY created_at DESC LIMIT 50`,
            [account.id]
        );

        return res.json({
            success: true,
            customer: userResult.rows[0],
            balance: account.balance,
            accountNumber: account.account_number,
            transactions: transactions.rows
        });
    } catch (error) {
        console.error("Dashboard error:", error.message);
        return res.status(500).json({ success: false, message: "Unable to load dashboard." });
    }
});

async function processTransaction(req, res, type) {
    const rawAmount = req.body.amount;
    const amountText = typeof rawAmount === "number" ? String(rawAmount) :
        (typeof rawAmount === "string" ? rawAmount.trim() : "");

    if (!/^(?:0|[1-9]\d{0,8})(?:\.\d{1,2})?$/.test(amountText) || Number(amountText) <= 0) {
        return res.status(400).json({
            success: false,
            message: "Enter a valid positive amount with no more than 2 decimal places (maximum ₦999,999,999.99)."
        });
    }

    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        const account = await ensureAccount(client, req.user.userId);

        const locked = await client.query(
            "SELECT id, balance FROM accounts WHERE id = $1 FOR UPDATE",
            [account.id]
        );
        const balance = Number(locked.rows[0].balance);
        const amount = Number(amountText);

        if (type === "withdrawal" && balance < amount) {
            await client.query("ROLLBACK");
            return res.status(400).json({ success: false, message: "Insufficient balance." });
        }

        const operator = type === "deposit" ? "+" : "-";
        await client.query(
            `UPDATE accounts SET balance = balance ${operator} $1::numeric WHERE id = $2`,
            [amountText, account.id]
        );
        await client.query(
            `INSERT INTO transactions (account_id, transaction_type, amount, description)
             VALUES ($1, $2, $3, $4)`,
            [account.id, type, amountText, type === "deposit" ? "Simulated deposit" : "Simulated withdrawal"]
        );

        await client.query("COMMIT");
        return res.json({
            success: true,
            message: type === "deposit" ? "Simulated deposit successful." : "Simulated withdrawal successful."
        });
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        console.error(`${type} error:`, error.message);
        return res.status(500).json({ success: false, message: "Transaction could not be completed." });
    } finally {
        client.release();
    }
}

router.post("/deposit", authMiddleware, (req, res) => processTransaction(req, res, "deposit"));
router.post("/withdrawal", authMiddleware, (req, res) => processTransaction(req, res, "withdrawal"));

module.exports = router;
