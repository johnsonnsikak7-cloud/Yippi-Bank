const jwt = require("jsonwebtoken");

function authMiddleware(req, res, next) {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) {
        return res.status(401).json({ success: false, message: "Authentication required." });
    }

    const token = header.slice(7).trim();
    if (!token) {
        return res.status(401).json({ success: false, message: "Authentication required." });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ["HS256"] });
        if (!decoded || !decoded.userId) {
            return res.status(401).json({ success: false, message: "Invalid or expired token." });
        }
        req.user = decoded;
        next();
    } catch {
        return res.status(401).json({ success: false, message: "Invalid or expired token." });
    }
}

module.exports = authMiddleware;
